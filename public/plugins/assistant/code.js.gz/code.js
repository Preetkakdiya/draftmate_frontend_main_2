(function(window, undefined) {
    var pollTimer = null;
    var lastSelectionSnapshot = '';
    var suppressSelectionSyncUntil = 0;

    var parentOrigin = '*';
    try {
        if (document.referrer) {
            parentOrigin = new URL(document.referrer).origin;
        }
    } catch (e) {}

    function postToParent(payload) {
        window.top.postMessage(payload, '*');
    }

    function getSelectedText(callback) {
        window.Asc.plugin.executeMethod('GetSelectedText', [{
            Numbering: false,
            Math: false,
            TableCellSeparator: '\n',
            ParaSeparator: '\n',
            TabSymbol: String.fromCharCode(9)
        }], function(text) {
            callback(String(text || ''));
        });
    }

    function escapeXml(unsafe) {
        return String(unsafe || '').replace(/[<>&'\"]/g, function(c) {
            switch (c) {
                case '<': return '&lt;';
                case '>': return '&gt;';
                case '&': return '&amp;';
                case '\'': return '&apos;';
                case '"': return '&quot;';
                default: return c;
            }
        });
    }

    function normalizeWhitespace(text) {
        return String(text || '')
            .replace(/\r\n?/g, '\n')
            .replace(/[ \t]{2,}/g, ' ')
            .replace(/\n{3,}/g, '\n\n');
    }

    function isHeadingLine(line) {
        var trimmed = String(line || '').trim();
        if (!trimmed) return false;

        if (/^(ARTICLE|SECTION|CLAUSE|INTRODUCTION|BACKGROUND|SUMMARY|CONCLUSION|PRAYER|RELIEF|DEFINITIONS)\b/i.test(trimmed)) {
            return true;
        }

        return trimmed.length <= 60 && !/[.!?]$/.test(trimmed) && trimmed === trimmed.toUpperCase();
    }

    function isListLine(line) {
        return /^\s*(?:\d+[\).]|[a-zA-Z][\).]|[-*])\s+/.test(String(line || ''));
    }

    function formatPlainText(text) {
        var normalized = normalizeWhitespace(text);
        var lines = normalized.split('\n');
        return lines.map(function(line) {
            return String(line || '').replace(/[ \t]{2,}/g, ' ').trimEnd();
        }).join('\n').trim();
    }

    function createCaseNameRuns(line) {
        var caseRegex = /\b([A-Z][A-Za-z0-9.&'/-]*(?:\s+[A-Z][A-Za-z0-9.&'/-]*)*)\s+v\.?\s+([A-Z][A-Za-z0-9.&'/-]*(?:\s+[A-Z][A-Za-z0-9.&'/-]*)*)\b|\bIn\s+re\s+([A-Z][A-Za-z0-9.&'/-]*(?:\s+[A-Z][A-Za-z0-9.&'/-]*)*)\b/g;
        var runXml = '';
        var cursor = 0;
        var match;

        function appendRun(text, bold, italic) {
            if (!text) return;
            runXml += '<w:r><w:rPr>';
            if (bold) runXml += '<w:b/>';
            if (italic) runXml += '<w:i/>';
            runXml += '</w:rPr><w:t xml:space="preserve">' + escapeXml(text) + '</w:t></w:r>';
        }

        while ((match = caseRegex.exec(line)) !== null) {
            if (match.index > cursor) {
                appendRun(line.slice(cursor, match.index), false, false);
            }
            appendRun(match[0], true, true);
            cursor = match.index + match[0].length;
        }

        if (cursor < line.length) {
            appendRun(line.slice(cursor), false, false);
        }

        return runXml || '<w:r><w:t xml:space="preserve">' + escapeXml(line) + '</w:t></w:r>';
    }

    function buildOoxml(text) {
        var paragraphs = [];
        var lines = normalizeWhitespace(text).split('\n');

        lines.forEach(function(rawLine) {
            var line = String(rawLine || '').trim();
            if (!line) {
                paragraphs.push('<w:p/>');
                return;
            }

            var pPr = '';
            var runs = '';

            if (isHeadingLine(line)) {
                runs = '<w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">' + escapeXml(line) + '</w:t></w:r>';
                pPr = '<w:pPr><w:jc w:val="left"/></w:pPr>';
            } else {
                runs = createCaseNameRuns(line);
            }

            paragraphs.push('<w:p>' + pPr + runs + '</w:p>');
        });

        return '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' +
            paragraphs.join('') +
            '<w:sectPr/></w:body></w:document>';
    }

    function emitSelectionState(text) {
        var snapshot = String(text || '').replace(/\s+$/g, '');
        if (snapshot === lastSelectionSnapshot) return;
        lastSelectionSnapshot = snapshot;
        postToParent({
            type: 'ONLYOFFICE_SELECTION_STATE',
            text: snapshot,
            hasSelection: !!snapshot.trim()
        });
    }

    function syncCurrentSelection() {
        var now = Date.now();
        if (now < suppressSelectionSyncUntil) return;

        getSelectedText(function(text) {
            emitSelectionState(text);
        });
    }

    function startSelectionWatcher() {
        if (pollTimer) return;
        syncCurrentSelection();
        pollTimer = window.setInterval(syncCurrentSelection, 400);
    }

    function stopSelectionWatcher() {
        if (pollTimer) {
            window.clearInterval(pollTimer);
            pollTimer = null;
        }
        lastSelectionSnapshot = '';
    }

    function convertUrlsToLinksInHtml(htmlContent) {
        if (!htmlContent) return '';

        // 1. Convert markdown style links: [Label](http://...)
        var mdLinkRegex = /\[([^\]]+)\]\((https?:\/\/[^\s\)]+|www\.[^\s\)]+|indiankanoon\.org\/[^\s\)]+)\)/gi;
        var processed = htmlContent.replace(mdLinkRegex, function(_, label, rawUrl) {
            var fullUrl = rawUrl.startsWith('http') ? rawUrl : ('https://' + rawUrl);
            return '<a href="' + fullUrl + '" target="_blank" style="color: #2563eb; text-decoration: underline; font-weight: 500;">' + label + '</a>';
        });

        // 2. Convert bare URLs: http://..., https://..., or indiankanoon.org/doc/...
        var bareUrlRegex = /(?<!href=")(https?:\/\/[^\s<>\)\]]+|(?<!\/)\b(?:www\.)?indiankanoon\.org\/[^\s<>\)\]]+)/gi;
        processed = processed.replace(bareUrlRegex, function(match) {
            var fullUrl = match.startsWith('http') ? match : ('https://' + match);
            return '<a href="' + fullUrl + '" target="_blank" style="color: #2563eb; text-decoration: underline; font-weight: 500;">' + match + '</a>';
        });

        return processed;
    }

    function formatCaseNamesInHtml(escapedText) {
        var caseRegex = /\b([A-Z][A-Za-z0-9.&'/-]*(?:\s+[A-Z][A-Za-z0-9.&'/-]*)*)\s+(?:vs\.?|v\.?)\s+([A-Z][A-Za-z0-9.&'/-]*(?:\s+[A-Z][A-Za-z0-9.&'/-]*)*)\b|\bIn\s+re\s+([A-Z][A-Za-z0-9.&'/-]*(?:\s+[A-Z][A-Za-z0-9.&'/-]*)*)\b/g;
        return escapedText.replace(caseRegex, function(match) {
            return '<em style="font-style: italic; font-weight: 600;">' + match + '</em>';
        });
    }

    function formatLegalDocumentHtml(text) {
        if (!text || !String(text).trim()) return '';

        var lines = String(text).split(/\r?\n/);
        var htmlBlocks = [];

        lines.forEach(function(rawLine) {
            var line = String(rawLine || '').trim();
            if (!line) {
                htmlBlocks.push('<p style="font-family: \'Times New Roman\', Times, serif; font-size: 11pt; line-height: 1.5; margin: 0; padding: 0; min-height: 11pt;">&nbsp;</p>');
                return;
            }

            var escaped = escapeXml(line);
            var isMainTitle = /^(IN THE|SUPREME COURT|HIGH COURT|BEFORE THE|PETITION|MEMORANDUM|DEED|AGREEMENT|SPECIAL LEAVE|RECORD OF PROCEEDINGS)\b/i.test(line);

            if (isMainTitle) {
                htmlBlocks.push(
                    '<p style="font-family: \'Times New Roman\', Times, serif; font-size: 14pt; font-weight: bold; color: #000000; margin-top: 10pt; margin-bottom: 4pt; text-align: center; line-height: 1.3;">' +
                    convertUrlsToLinksInHtml(escaped) +
                    '</p>'
                );
            } else if (isHeadingLine(line)) {
                htmlBlocks.push(
                    '<p style="font-family: \'Times New Roman\', Times, serif; font-size: 12pt; font-weight: bold; color: #000000; margin-top: 8pt; margin-bottom: 3pt; text-align: left; line-height: 1.3;">' +
                    convertUrlsToLinksInHtml(escaped) +
                    '</p>'
                );
            } else {
                htmlBlocks.push(
                    '<p style="font-family: \'Times New Roman\', Times, serif; font-size: 11pt; line-height: 1.5; color: #111827; margin-top: 0pt; margin-bottom: 4pt; text-align: justify; word-wrap: break-word;">' +
                    convertUrlsToLinksInHtml(formatCaseNamesInHtml(escaped)) +
                    '</p>'
                );
            }
        });

        return '<div style="font-family: \'Times New Roman\', Times, serif; font-size: 11pt; line-height: 1.5; color: #111827; width: 100%; box-sizing: border-box; margin: 0; padding: 0;">\n' + htmlBlocks.join('\n') + '\n</div>';
    }

    function resetAllParagraphRightIndents() {
        try {
            window.Asc.plugin.callCommand(function() {
                var oDocument = Api.GetDocument();
                if (!oDocument) return;
                var aParagraphs = oDocument.GetAllParagraphs();
                if (aParagraphs && aParagraphs.length) {
                    for (var i = 0; i < aParagraphs.length; i++) {
                        try {
                            if (aParagraphs[i]) {
                                aParagraphs[i].SetIndRight(0);
                            }
                        } catch (e) {}
                    }
                }
            }, false);
        } catch (err) {
            console.warn('[ONLYOFFICE Plugin] resetAllParagraphRightIndents failed:', err);
        }
    }

    function scheduleIndentReset() {
        resetAllParagraphRightIndents();
        setTimeout(resetAllParagraphRightIndents, 150);
        setTimeout(resetAllParagraphRightIndents, 400);
        setTimeout(resetAllParagraphRightIndents, 800);
    }

    function detectCourtPresetFromText(text) {
        var sample = String(text || '').slice(0, 4000).toUpperCase();

        if (/HIGH COURT OF DELHI|DELHI HIGH COURT|IN THE HIGH COURT OF DELHI|TIS HAZARI|PATIALA HOUSE|KARKARDOOMA|ROHINI COURT|DWARKA COURT|SAKET COURT/i.test(sample)) {
            return {
                id: 'delhi_hc', name: 'Delhi High Court & District Courts', paper: 'A4',
                widthDxa: 11906, heightDxa: 16838, fontFamily: 'Times New Roman',
                bodyFontSize: 28, headingFontSize: 32, quoteFontSize: 24, lineSpacing: 360,
                marginTopDxa: 1134, marginBottomDxa: 1134, marginLeftDxa: 2268, marginRightDxa: 2268, alignment: 'justify'
            };
        }

        if (/PUNJAB AND HARYANA|PUNJAB & HARYANA|HIGH COURT OF PUNJAB|CHANDIGARH HIGH COURT|HIGH COURT AT CHANDIGARH/i.test(sample)) {
            return {
                id: 'punjab_haryana_hc', name: 'Punjab & Haryana High Court', paper: 'A4',
                widthDxa: 11906, heightDxa: 16838, fontFamily: 'Times New Roman',
                bodyFontSize: 28, headingFontSize: 32, quoteFontSize: 24, lineSpacing: 480,
                marginTopDxa: 1800, marginBottomDxa: 1080, marginLeftDxa: 1800, marginRightDxa: 1800, alignment: 'justify'
            };
        }

        if (/HIMACHAL PRADESH|HIGH COURT OF HIMACHAL|HIGH COURT AT SHIMLA/i.test(sample)) {
            return {
                id: 'hp_hc', name: 'Himachal Pradesh High Court', paper: 'A4',
                widthDxa: 11906, heightDxa: 16838, fontFamily: 'Times New Roman',
                bodyFontSize: 32, headingFontSize: 36, quoteFontSize: 28, lineSpacing: 360,
                marginTopDxa: 1134, marginBottomDxa: 1134, marginLeftDxa: 2268, marginRightDxa: 2268, alignment: 'justify'
            };
        }

        if (/DISTRICT & SESSIONS|DISTRICT COURT|NCLT|TRIBUNAL|CONSUMER COMMISSION|FAMILY COURT|BEFORE THE LEARNED/i.test(sample)) {
            return {
                id: 'district_court', name: 'Generic District Court / Tribunal', paper: 'A4',
                widthDxa: 11906, heightDxa: 16838, fontFamily: 'Times New Roman',
                bodyFontSize: 28, headingFontSize: 32, quoteFontSize: 24, lineSpacing: 360,
                marginTopDxa: 1440, marginBottomDxa: 1440, marginLeftDxa: 2160, marginRightDxa: 1440, alignment: 'justify'
            };
        }

        return {
            id: 'supreme_court', name: 'Supreme Court of India', paper: 'A4',
            widthDxa: 11906, heightDxa: 16838, fontFamily: 'Times New Roman',
            bodyFontSize: 28, headingFontSize: 32, quoteFontSize: 24, lineSpacing: 360,
            marginTopDxa: 1134, marginBottomDxa: 1134, marginLeftDxa: 2268, marginRightDxa: 2268, alignment: 'justify'
        };
    }

    function applyAutoFormat(courtPreset) {
        getSelectedText(function(selectedText) {
            var preset = courtPreset || detectCourtPresetFromText(selectedText);
            var cleaned = formatPlainText(selectedText);

            if (!cleaned.trim()) {
                postToParent({
                    type: 'ONLYOFFICE_AUTOFORMAT_DONE',
                    applied: false,
                    reason: 'empty-selection'
                });
                return;
            }

            suppressSelectionSyncUntil = Date.now() + 1500;
            lastSelectionSnapshot = '';

            try {
                window.Asc.scope.preset = preset;
                window.Asc.plugin.callCommand(function() {
                    var pConfig = Asc.scope.preset || {};
                    var oDocument = Api.GetDocument();
                    if (!oDocument) return;

                    try {
                        var oSection = oDocument.GetFinalSection();
                        if (oSection && pConfig.marginLeftDxa) {
                            oSection.SetPageSize(pConfig.widthDxa || 11906, pConfig.heightDxa || 16838);
                            oSection.SetPageMargins(
                                pConfig.marginLeftDxa,
                                pConfig.marginTopDxa,
                                pConfig.marginRightDxa,
                                pConfig.marginBottomDxa
                            );
                        }
                    } catch(e) {}

                    var oRange = oDocument.GetRangeBySelect();
                    var aParagraphs = (oRange && typeof oRange.GetAllParagraphs === 'function') ? oRange.GetAllParagraphs() : oDocument.GetAllParagraphs();
                    if (!aParagraphs || !aParagraphs.length) {
                        aParagraphs = oDocument.GetAllParagraphs();
                    }

                    if (aParagraphs && aParagraphs.length) {
                        for (var i = 0; i < aParagraphs.length; i++) {
                            var p = aParagraphs[i];
                            if (p) {
                                try { p.SetIndRight(0); } catch(e) {}
                                try { p.SetIndLeft(0); } catch(e) {}
                                try { p.SetIndFirstLine(0); } catch(e) {}
                                try { p.SetFontFamily(pConfig.fontFamily || "Times New Roman"); } catch(e) {}
                                try { p.SetAlign(pConfig.alignment || "justify"); } catch(e) {}
                                try { p.SetSpacingAfter(120); } catch(e) {}

                                try {
                                    var text = (p.GetText() || "").trim();
                                    var isTitle = /^(IN THE|SUPREME COURT|HIGH COURT|BEFORE THE|RECORD OF PROCEEDINGS)\b/i.test(text);
                                    if (isTitle) {
                                        p.SetAlign("center");
                                        p.SetBold(true);
                                        p.SetFontSize(28); // 14pt
                                    } else if (text.length > 0 && text.length <= 60 && !/[.!?]$/.test(text) && text === text.toUpperCase()) {
                                        p.SetAlign("left");
                                        p.SetBold(true);
                                        p.SetFontSize(24); // 12pt
                                    } else {
                                        p.SetAlign("justify");
                                        p.SetBold(false);
                                        p.SetFontSize(24); // 12pt
                                    }
                                } catch(e) {}
                            }
                        }
                    }
                }, false);

                postToParent({
                    type: 'ONLYOFFICE_AUTOFORMAT_DONE',
                    applied: true
                });
            } catch (error) {
                console.warn('[ONLYOFFICE Plugin] Native court auto-format failed, falling back to PasteText:', error);
                try {
                    window.Asc.plugin.executeMethod('PasteText', [cleaned]);
                    scheduleIndentReset();
                    postToParent({
                        type: 'ONLYOFFICE_AUTOFORMAT_DONE',
                        applied: true
                    });
                } catch (fallbackErr) {
                    postToParent({
                        type: 'ONLYOFFICE_AUTOFORMAT_ERROR',
                        message: fallbackErr && fallbackErr.message ? fallbackErr.message : 'Auto format failed.'
                    });
                }
            }
        });
    }

    function requestEnhanceSelection() {
        getSelectedText(function(selectedText) {
            var cleaned = formatPlainText(selectedText);
            postToParent({
                type: 'ONLYOFFICE_ENHANCE_SELECTION',
                text: cleaned || ''
            });
        });
    }

    function detectVariablesFromDocument() {
        try {
            window.Asc.plugin.callCommand(function() {
                var oDocument = Api.GetDocument();
                var foundVars = [];
                var ignoreSet = {
                    'THE': 1, 'AND': 1, 'FOR': 1, 'THAT': 1, 'THIS': 1, 'WITH': 1, 'FROM': 1,
                    'SHALL': 1, 'BEING': 1, 'UNDER': 1, 'UPON': 1, 'SAID': 1, 'HERETO': 1,
                    'OTHER': 1, 'COURT': 1, 'HIGH': 1, 'INDIA': 1, 'ACT': 1, 'SECTION': 1
                };

                // 1. Scan Content Controls by tag
                var aControls = oDocument.GetAllContentControls();
                if (aControls && aControls.length > 0) {
                    for (var i = 0; i < aControls.length; i++) {
                        var tag = aControls[i].GetTag();
                        if (tag && tag.trim() && foundVars.indexOf(tag.trim()) === -1) {
                            foundVars.push(tag.trim());
                        }
                    }
                }

                // 2. Scan Document Text for ALL_CAPS placeholders / bracketed tags
                var docText = oDocument.GetText();
                if (docText) {
                    var regex = /\[([A-Z0-9_]{2,40})\]|\{([A-Z0-9_]{2,40})\}|\b([A-Z0-9_]{3,35})\b/g;
                    var match;
                    while ((match = regex.exec(docText)) !== null) {
                        var v = (match[1] || match[2] || match[3] || '').trim();
                        if (v && v.length >= 3 && !ignoreSet[v] && foundVars.indexOf(v) === -1) {
                            if (/^[A-Z0-9_]+$/.test(v)) {
                                foundVars.push(v);
                            }
                        }
                    }
                }
                return foundVars;
            }, false, true, function(result) {
                if (Array.isArray(result) && result.length > 0) {
                    postToParent({
                        type: 'ONLYOFFICE_VARIABLES_DETECTED',
                        variables: result
                    });
                }
            });
        } catch (e) {
            console.warn('[ONLYOFFICE Plugin] Variable detection failed:', e);
        }
    }

    function navigateToVariableInDocument(tagToFind) {
        if (!tagToFind) return;
        try {
            window.Asc.scope.targetTag = tagToFind;
            window.Asc.plugin.callCommand(function() {
                var oDocument = Api.GetDocument();
                var target = Asc.scope.targetTag;
                if (!target) return;

                // 1. Try content control by tag
                var aContentControls = oDocument.GetContentControlsByTag(target);
                if (aContentControls && aContentControls.length > 0) {
                    aContentControls[0].GetRange().Select();
                    return;
                }

                // 2. Try exact search for tag or [tag] or {tag}
                var aSearch = oDocument.Search(target, false);
                if (aSearch && aSearch.length > 0) {
                    aSearch[0].Select();
                    return;
                }

                var bracketSearch = oDocument.Search('[' + target + ']', false);
                if (bracketSearch && bracketSearch.length > 0) {
                    bracketSearch[0].Select();
                }
            }, false);
        } catch (e) {
            console.warn('[ONLYOFFICE Plugin] Navigate to variable failed:', e);
        }
    }

    window.Asc.plugin.init = function() {
        postToParent({ type: 'ONLYOFFICE_PLUGIN_READY' });
        startSelectionWatcher();
        setTimeout(function() {
            detectVariablesFromDocument();
        }, 1200);
    };

    window.Asc.plugin.button = function(id) {
        stopSelectionWatcher();
        this.executeCommand('close', '');
    };

    window.addEventListener('message', function(event) {
        if (!event.data) return;

        if (event.data.type === 'ONLYOFFICE_GET_SELECTION') {
            getSelectedText(function(text) {
                postToParent({
                    type: 'ONLYOFFICE_SELECTION',
                    text: text || ''
                });
            });
        } else if (event.data.type === 'ONLYOFFICE_POLL_SELECTION') {
            getSelectedText(function(text) {
                postToParent({
                    type: 'ONLYOFFICE_SELECTION_STATE',
                    text: text || '',
                    hasSelection: !!String(text || '').trim()
                });
            });
        } else if (event.data.type === 'ONLYOFFICE_INSERT_HTML') {
            var rawHtml = String(event.data.html || '');
            console.log('[ONLYOFFICE Plugin] Received ONLYOFFICE_INSERT_HTML payload (length: ' + rawHtml.length + ')');
            try {
                window.Asc.plugin.executeMethod('PasteHtml', [rawHtml]);
                scheduleIndentReset();
                console.log('[ONLYOFFICE Plugin] PasteHtml executed successfully.');
            } catch (err) {
                console.error('[ONLYOFFICE Plugin] PasteHtml execution failed:', err);
            }
        } else if (event.data.type === 'ONLYOFFICE_INSERT_TEXT') {
            var rawText = String(event.data.text || '');
            var formattedHtml = formatLegalDocumentHtml(rawText);
            try {
                if (formattedHtml) {
                    window.Asc.plugin.executeMethod('PasteHtml', [formattedHtml]);
                } else {
                    window.Asc.plugin.executeMethod('PasteText', [rawText]);
                }
                scheduleIndentReset();
            } catch (err) {
                console.warn('[ONLYOFFICE Plugin] PasteHtml failed in ONLYOFFICE_INSERT_TEXT, falling back to PasteText:', err);
                try {
                    window.Asc.plugin.executeMethod('PasteText', [rawText]);
                    scheduleIndentReset();
                } catch (e) {}
            }
        } else if (event.data.type === 'ONLYOFFICE_AUTO_FORMAT_SELECTION') {
            applyAutoFormat(event.data.courtPreset || event.data.preset);
        } else if (event.data.type === 'ONLYOFFICE_ENHANCE_WITH_AI') {
            requestEnhanceSelection();
        } else if (event.data.type === 'ONLYOFFICE_DETECT_VARIABLES') {
            detectVariablesFromDocument();
        } else if (event.data.type === 'ONLYOFFICE_NAVIGATE_TO_VARIABLE') {
            navigateToVariableInDocument(event.data.tag);
        }
    });
})(window, undefined);
